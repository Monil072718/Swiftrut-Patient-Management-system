const Invoice = require('../models/invoiceModel');
const { generateInvoicePDF } = require('../utils/invoiceGenerator');

const createInvoice = async (req, res) => {
    try {
        const invoiceData = req.body;

        // Save invoice to DB
        const invoice = new Invoice(invoiceData);
        await invoice.save();

        // Generate PDF
        const invoicePDF = await generateInvoicePDF(invoice);

        res.status(201).json({ success: true, invoice, invoicePDF });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

module.exports = {
    createInvoice
}