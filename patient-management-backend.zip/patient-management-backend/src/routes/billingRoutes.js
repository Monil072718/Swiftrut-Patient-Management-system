const express = require('express');
const { createInvoice } = require('../controllers/billingController');
const router = express.Router();

router.post('/create-invoice', createInvoice);

module.exports = router;
