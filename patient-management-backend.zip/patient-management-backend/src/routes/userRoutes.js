const express = require('express');
const { register, login, forgetPassword,getPatientById,updatePatientRecord } = require('../controllers/userController');
const { protect } = require('../middleware/roleMiddleware');
const {authorize} = require('../middleware/authMiddleware');
const router = express.Router();

// Public routes
router.post('/register', register);
router.post('/login', login);
router.post('/forgot-password', forgetPassword);
router.get('/:id',authorize,getPatientById);
router.put('/:id',authorize,updatePatientRecord);

// Only accessible by doctors
router.get('/doctor-protected-route', protect(['doctor']), (req, res) => {
    res.status(200).json({ message: 'Welcome Doctor!' });
});

// Only accessible by patients
router.get('/patient-protected-route', protect(['patient']), (req, res) => {
    res.status(200).json({ message: 'Welcome Patient!' });
});

module.exports = router;
