const express = require('express');
const { createPrescription,getPrescription,updatePrescription } = require('../controllers/prescriptionController');
const{authorize}=require('../middleware/authMiddleware');
const router = express.Router();

router.post('/',authorize,createPrescription);
router.get('/:patientId',authorize,getPrescription);
router.put('/:patientId',authorize,updatePrescription);

module.exports = router;