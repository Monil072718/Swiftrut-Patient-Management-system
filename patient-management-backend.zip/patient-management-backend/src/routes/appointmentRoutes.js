const express = require("express");
const { createAppointment ,getAppointment,updateAppointment ,deleteAppointment,getAppointmentHistory} = require('../controllers/appointmentController');
const {authorize} = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/', authorize, createAppointment);
router.get('/',authorize,getAppointment);
router.put('/:id',authorize,updateAppointment);
router.delete('/:id',authorize,deleteAppointment);
router.get('/history',getAppointmentHistory);

module.exports = router;